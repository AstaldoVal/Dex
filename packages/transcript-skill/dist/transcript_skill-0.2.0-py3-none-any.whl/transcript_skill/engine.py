"""Transcription logic: YouTube captions, local Whisper, Apple Podcasts via yt-dlp."""

from __future__ import annotations

import json
import re
import shutil
import tempfile
from pathlib import Path

from transcript_skill import SCHEMA_VERSION

LOCAL_MEDIA_EXTENSIONS = {
    ".mp4",
    ".m4v",
    ".mov",
    ".mkv",
    ".webm",
    ".avi",
    ".mp3",
    ".m4a",
    ".wav",
    ".flac",
    ".ogg",
    ".opus",
}

# Default matches previous Dex behavior; override via CLI --model.
DEFAULT_WHISPER_MODEL = "small"

# faster-whisper model ids (see SYSTRAN/faster-whisper README).
WHISPER_MODEL_CHOICES = (
    "tiny",
    "base",
    "small",
    "medium",
    "large-v1",
    "large-v2",
    "large-v3",
)


def extract_video_id(url: str) -> str | None:
    if not url or not url.strip():
        return None
    normalized = url.strip()
    match = re.search(
        r"(?:youtube\.com/watch\?v=|youtube\.com/embed/|youtu\.be/)([a-zA-Z0-9_-]{11})",
        normalized,
    )
    if match:
        return match.group(1)
    if re.match(r"^[a-zA-Z0-9_-]{11}$", normalized):
        return normalized
    return None


def is_apple_podcast_url(url: str) -> bool:
    if not url:
        return False
    normalized = url.strip().lower()
    return normalized.startswith("http") and "podcasts.apple.com" in normalized


def is_local_media_path(raw: str) -> bool:
    if not raw:
        return False
    expanded = Path(raw).expanduser()
    return expanded.suffix.lower() in LOCAL_MEDIA_EXTENSIONS


def normalize_local_path(raw: str) -> Path:
    return Path(raw).expanduser().resolve()


def format_local_segments(segments):
    normalized = []
    for seg in segments:
        start = float(getattr(seg, "start", 0.0) or 0.0)
        end = float(getattr(seg, "end", start) or start)
        duration = max(0.0, end - start)
        text = (getattr(seg, "text", None) or "").strip().replace("\n", " ")
        if text:
            normalized.append({"start": start, "duration": duration, "text": text})
    return normalized


def transcribe_local_file(
    source_path: Path,
    *,
    whisper_model: str = DEFAULT_WHISPER_MODEL,
    language: str | None = None,
    compute_type: str = "int8",
) -> dict:
    if not source_path.exists():
        raise RuntimeError(f"Local file not found: {source_path}")
    if not source_path.is_file():
        raise RuntimeError(f"Path is not a file: {source_path}")
    if source_path.suffix.lower() not in LOCAL_MEDIA_EXTENSIONS:
        raise RuntimeError(
            f"Unsupported local media format: {source_path.suffix}. "
            f"Supported: {', '.join(sorted(LOCAL_MEDIA_EXTENSIONS))}"
        )

    if shutil.which("ffmpeg") is None:
        raise RuntimeError("Missing dependency: ffmpeg is not installed or not in PATH.")

    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError("Missing dependency. Run: pip install faster-whisper") from exc

    model = WhisperModel(whisper_model, device="auto", compute_type=compute_type)
    kwargs = {"vad_filter": True}
    if language:
        kwargs["language"] = language
    segments_iter, _info = model.transcribe(str(source_path), **kwargs)
    segments = list(segments_iter)
    out_segments = format_local_segments(segments)
    if not out_segments:
        raise RuntimeError("Transcript is empty.")

    transcript_text = " ".join(seg["text"] for seg in out_segments)
    return {
        "ok": True,
        "schema_version": SCHEMA_VERSION,
        "source_type": "local_file",
        "source_path": str(source_path),
        "whisper_model": whisper_model,
        "transcript": transcript_text,
        "segments": out_segments,
    }


def transcribe_youtube(video_id: str) -> dict:
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
    except ImportError as exc:
        raise RuntimeError("Missing dependency. Run: pip install youtube-transcript-api") from exc

    try:
        api = YouTubeTranscriptApi()
        fetched = api.fetch(video_id=video_id)
        segments = list(fetched)
    except Exception as exc:
        err = str(exc).strip()
        if "TranscriptsDisabled" in type(exc).__name__ or "disabled" in err.lower():
            msg = "Captions are disabled for this video."
        elif "VideoUnavailable" in type(exc).__name__ or "unavailable" in err.lower():
            msg = "Video is unavailable or private."
        elif "NoTranscriptFound" in type(exc).__name__ or "no transcript" in err.lower():
            msg = "No transcript available for this video (no captions)."
        else:
            msg = err or "Failed to fetch transcript."
        raise RuntimeError(msg) from exc

    if not segments:
        raise RuntimeError("Transcript is empty.")

    def seg_to_dict(segment):
        if isinstance(segment, dict):
            return {
                "start": segment.get("start", 0),
                "duration": segment.get("duration", 0),
                "text": (segment.get("text") or "").strip(),
            }
        return {
            "start": getattr(segment, "start", 0),
            "duration": getattr(segment, "duration", 0),
            "text": (getattr(segment, "text", None) or "").strip(),
        }

    out_segments = [seg_to_dict(seg) for seg in segments]
    transcript_text = " ".join(seg["text"] for seg in out_segments if seg["text"])

    return {
        "ok": True,
        "schema_version": SCHEMA_VERSION,
        "source_type": "youtube",
        "video_id": video_id,
        "transcript": transcript_text,
        "segments": out_segments,
    }


def download_apple_podcast_audio(url: str) -> Path:
    try:
        from yt_dlp import YoutubeDL
    except ImportError as exc:
        raise RuntimeError("Missing dependency. Run: pip install yt-dlp") from exc

    temp_dir = tempfile.mkdtemp(prefix="apple_podcast_")
    output_template = str(Path(temp_dir) / "source.%(ext)s")
    options = {
        "format": "bestaudio/best",
        "outtmpl": output_template,
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "postprocessors": [
            {
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }
        ],
    }

    try:
        with YoutubeDL(options) as ydl:
            ydl.download([url])
    except Exception as exc:
        raise RuntimeError(f"Failed to download Apple Podcasts audio: {exc}") from exc

    media_files = sorted(Path(temp_dir).glob("source.*"))
    if not media_files:
        raise RuntimeError("Apple Podcasts audio was downloaded but no media file was found.")
    return media_files[0]


def transcribe_apple_podcast(
    url: str,
    *,
    whisper_model: str = DEFAULT_WHISPER_MODEL,
    language: str | None = None,
    compute_type: str = "int8",
) -> dict:
    downloaded_path = download_apple_podcast_audio(url)
    result = transcribe_local_file(
        downloaded_path,
        whisper_model=whisper_model,
        language=language,
        compute_type=compute_type,
    )
    result["source_type"] = "apple_podcast"
    result["source_url"] = url
    return result


def transcribe_from_input(
    raw: str,
    *,
    whisper_model: str = DEFAULT_WHISPER_MODEL,
    language: str | None = None,
    compute_type: str = "int8",
) -> dict:
    """Route a single URL or path string to the right backend."""
    raw = raw.strip()
    if not raw:
        raise RuntimeError(
            "Missing input. Provide YouTube URL, Apple Podcasts URL, or local media path."
        )

    video_id = extract_video_id(raw)
    if video_id:
        return transcribe_youtube(video_id=video_id)
    if is_apple_podcast_url(raw):
        return transcribe_apple_podcast(
            raw,
            whisper_model=whisper_model,
            language=language,
            compute_type=compute_type,
        )
    if is_local_media_path(raw):
        return transcribe_local_file(
            normalize_local_path(raw),
            whisper_model=whisper_model,
            language=language,
            compute_type=compute_type,
        )

    possible_path = Path(raw).expanduser()
    if possible_path.exists():
        return transcribe_local_file(
            normalize_local_path(raw),
            whisper_model=whisper_model,
            language=language,
            compute_type=compute_type,
        )

    raise RuntimeError(
        "Invalid input. Use YouTube URL, Apple Podcasts URL, or a local media file path."
    )


def output_json(payload: dict) -> str:
    return json.dumps(payload, ensure_ascii=False)
