"""CLI: transcript-media — JSON to stdout."""

from __future__ import annotations

import argparse
import sys

from transcript_skill.engine import WHISPER_MODEL_CHOICES, output_json, transcribe_from_input


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="transcript-media",
        description="Transcribe YouTube (captions), Apple Podcasts, or local media. Prints JSON to stdout.",
    )
    p.add_argument(
        "input",
        nargs="?",
        default="",
        help="YouTube URL, Apple Podcasts URL, or path to local audio/video",
    )
    p.add_argument(
        "--model",
        default="small",
        metavar="NAME",
        help=f"faster-whisper model for local/podcast paths (default: small). Choices: {', '.join(WHISPER_MODEL_CHOICES)}",
    )
    p.add_argument(
        "--language",
        default="",
        metavar="CODE",
        help="Optional Whisper language code (e.g. en, ru). Empty = auto-detect.",
    )
    p.add_argument(
        "--compute-type",
        default="int8",
        metavar="TYPE",
        help="faster-whisper compute_type (default: int8)",
    )
    return p


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    raw = (args.input or "").strip()
    if not raw:
        import json

        print(
            json.dumps(
                {
                    "ok": False,
                    "error": "Missing input. Provide YouTube URL, Apple Podcasts URL, or local media path.",
                },
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        sys.exit(1)

    model = args.model.strip()
    if model not in WHISPER_MODEL_CHOICES:
        import json

        print(
            json.dumps(
                {
                    "ok": False,
                    "error": f"Invalid --model {model!r}. Use one of: {', '.join(WHISPER_MODEL_CHOICES)}",
                },
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        sys.exit(1)

    lang = args.language.strip() or None

    try:
        out = transcribe_from_input(
            raw,
            whisper_model=model,
            language=lang,
            compute_type=args.compute_type.strip() or "int8",
        )
        print(output_json(out))
    except Exception as exc:
        import json

        print(
            json.dumps(
                {"ok": False, "error": str(exc).strip() or "Transcription failed."},
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
