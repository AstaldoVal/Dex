"""Standalone transcript package: YouTube, Apple Podcasts, local media."""

__version__ = "0.2.0"
# Bump when JSON shape or semantics change for downstream tools.
SCHEMA_VERSION = "1"
